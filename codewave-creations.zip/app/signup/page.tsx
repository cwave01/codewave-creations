export default function SignUp() {
  return (
    <div className="max-w-md mx-auto mt-20">
      <h2 className="text-3xl font-bold mb-4">Create an account</h2>
      <form className="space-y-4">
        <input type="email" placeholder="Email" className="w-full p-3 border rounded" />
        <input type="password" placeholder="Password" className="w-full p-3 border rounded" />
        <button className="w-full bg-blue-600 text-white py-2 rounded">Sign Up</button>
      </form>
    </div>
  );
}