export default function LaunchLayer() {
  return (
    <div className="max-w-2xl mx-auto p-10">
      <h2 className="text-3xl font-bold mb-6">LaunchLayer: Create a Website</h2>
      <form className="space-y-6">
        <div>
          <label className="block mb-2 font-semibold">Choose a Site Type:</label>
          <select className="w-full p-3 border rounded">
            <option>Single Page</option>
            <option>3-Page Website</option>
          </select>
        </div>
        <div>
          <label className="block mb-2 font-semibold">Business Name:</label>
          <input type="text" placeholder="e.g. The Local Bakery" className="w-full p-3 border rounded" />
        </div>
        <div>
          <label className="block mb-2 font-semibold">Description/About:</label>
          <textarea className="w-full p-3 border rounded" rows={4}></textarea>
        </div>
        <button className="w-full bg-blue-600 text-white py-2 rounded">Publish Website</button>
      </form>
    </div>
  );
}