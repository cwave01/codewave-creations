export default function Dashboard() {
  return (
    <div className="p-10">
      <h1 className="text-4xl font-bold mb-4">Dashboard</h1>
      <div className="space-y-4">
        <a href="/dashboard/launchlayer" className="block p-4 bg-gray-100 rounded hover:bg-gray-200">LaunchLayer - Create Website</a>
      </div>
    </div>
  );
}